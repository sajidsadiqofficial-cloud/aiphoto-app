package com.aiphotos.maker

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.aiphotos.maker.databinding.ItemHistoryBinding

class HistoryAdapter(
    private var items: List<HistoryItem>,
    private val onClick: (HistoryItem) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemHistoryBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvPrompt.text = item.prompt
        holder.binding.ivThumb.setImageBitmap(decodeThumbnail(item.filePath))
        holder.binding.root.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size

    fun updateItems(newItems: List<HistoryItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    private fun decodeThumbnail(path: String) = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        val opts = BitmapFactory.Options().apply {
            inSampleSize = calculateInSampleSize(bounds, 220, 220)
            inJustDecodeBounds = false
        }
        BitmapFactory.decodeFile(path, opts)
    } catch (_: Exception) {
        null
    }

    private fun calculateInSampleSize(
        opts: BitmapFactory.Options, reqWidth: Int, reqHeight: Int
    ): Int {
        var inSampleSize = 1
        val height = opts.outHeight
        val width = opts.outWidth
        while (height / inSampleSize >= reqHeight * 2 &&
            width / inSampleSize >= reqWidth * 2
        ) {
            inSampleSize *= 2
        }
        return inSampleSize
    }
}
