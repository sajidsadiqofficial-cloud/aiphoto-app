package com.aiphotos.maker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persists the generation history as JSON in internal storage.
 * Keeps the newest [MAX_ITEMS] entries; deletes image files that fall off the list.
 */
class HistoryStore(context: Context) {

    private val file = File(context.filesDir, "history.json")

    companion object {
        private const val MAX_ITEMS = 20
    }

    fun load(): List<HistoryItem> {
        if (!file.exists()) return emptyList()
        return try {
            val items = mutableListOf<HistoryItem>()
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val path = o.optString("filePath")
                if (path.isNotEmpty() && File(path).exists()) {
                    items.add(
                        HistoryItem(
                            prompt = o.optString("prompt"),
                            filePath = path,
                            timestamp = o.optLong("timestamp")
                        )
                    )
                }
            }
            items
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(item: HistoryItem) {
        try {
            val previous = load()
            val items = (listOf(item) + previous).take(MAX_ITEMS)

            // Delete image files that are no longer in the list.
            val keptPaths = items.map { it.filePath }.toSet()
            for (old in previous) {
                if (old.filePath !in keptPaths) {
                    try { File(old.filePath).delete() } catch (_: Exception) { }
                }
            }

            val arr = JSONArray()
            for (entry in items) {
                arr.put(
                    JSONObject().apply {
                        put("prompt", entry.prompt)
                        put("filePath", entry.filePath)
                        put("timestamp", entry.timestamp)
                    }
                )
            }
            file.writeText(arr.toString())
        } catch (_: Exception) {
            // History is best-effort; never crash the app over it.
        }
    }
}
