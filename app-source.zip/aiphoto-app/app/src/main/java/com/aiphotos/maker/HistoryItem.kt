package com.aiphotos.maker

/** One generated photo stored in the app's private files. */
data class HistoryItem(
    val prompt: String,
    val filePath: String,
    val timestamp: Long
)
