package com.aiphotos.maker

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.aiphotos.maker.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var historyStore: HistoryStore
    private lateinit var historyAdapter: HistoryAdapter

    private var currentBitmap: Bitmap? = null
    private var pendingSaveAfterPermission = false

    private val styleOptions = listOf(
        "Photorealistic" to ", photorealistic, ultra detailed, sharp focus, 8k",
        "Anime" to ", anime style, vibrant colors, detailed",
        "Digital Art" to ", digital art, trending on artstation, highly detailed",
        "3D Render" to ", 3d render, octane render, soft studio lighting",
        "Pencil Sketch" to ", pencil sketch, hand drawn, detailed shading"
    )

    private val sizeOptions = listOf(
        "Square 1024x1024" to Pair(1024, 1024),
        "Portrait 1024x1536" to Pair(1024, 1536),
        "Landscape 1536x1024" to Pair(1536, 1024)
    )

    companion object {
        private const val REQ_STORAGE = 1001
        const val EXTRA_FILE_PATH = "extra_file_path"
        const val EXTRA_PROMPT = "extra_prompt"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        historyStore = HistoryStore(this)

        binding.spinnerStyle.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, styleOptions.map { it.first }
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        binding.spinnerSize.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item, sizeOptions.map { it.first }
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        historyAdapter = HistoryAdapter(historyStore.load()) { item ->
            val intent = Intent(this, HistoryActivity::class.java).apply {
                putExtra(EXTRA_FILE_PATH, item.filePath)
                putExtra(EXTRA_PROMPT, item.prompt)
            }
            startActivity(intent)
        }
        binding.recyclerHistory.layoutManager = GridLayoutManager(this, 3)
        binding.recyclerHistory.isNestedScrollingEnabled = false
        binding.recyclerHistory.adapter = historyAdapter

        binding.btnGenerate.setOnClickListener { generatePhoto() }
        binding.btnSave.setOnClickListener { saveToGallery() }
    }

    override fun onResume() {
        super.onResume()
        refreshHistory()
    }

    private fun generatePhoto() {
        val prompt = binding.etPrompt.text.toString().trim()
        if (prompt.isEmpty()) {
            binding.etPrompt.error = getString(R.string.error_empty_prompt)
            return
        }
        val styleSuffix = styleOptions[binding.spinnerStyle.selectedItemPosition].second
        val (width, height) = sizeOptions[binding.spinnerSize.selectedItemPosition].second
        val fullPrompt = prompt + styleSuffix
        val seed = (0..999999).random()
        // URLEncoder turns spaces into "+"; in a URL path that must be "%20".
        val encoded = URLEncoder.encode(fullPrompt, "UTF-8").replace("+", "%20")
        val url =
            "https://image.pollinations.ai/prompt/$encoded" +
                "?width=$width&height=$height&seed=$seed&model=flux&nologo=true"

        setLoading(true)
        hideError()

        scope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) { downloadBitmap(url) }
                    ?: throw IllegalStateException("decode_failed")
                withContext(Dispatchers.IO) { saveToInternalStorage(bitmap, prompt) }
                currentBitmap = bitmap
                binding.ivResult.setImageBitmap(bitmap)
                binding.tvPlaceholder.visibility = View.GONE
                binding.ivResult.visibility = View.VISIBLE
                binding.btnSave.visibility = View.VISIBLE
                refreshHistory()
            } catch (_: Exception) {
                showError(getString(R.string.error_network))
            } finally {
                setLoading(false)
            }
        }
    }

    private fun downloadBitmap(urlString: String): Bitmap? {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "AIPhotoMaker/1.0")
        }
        connection.connect()
        try {
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                throw IllegalStateException("http_${connection.responseCode}")
            }
            connection.inputStream.use { input ->
                return BitmapFactory.decodeStream(input)
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun saveToInternalStorage(bitmap: Bitmap, prompt: String) {
        val dir = File(filesDir, "generated").apply { mkdirs() }
        val file = File(dir, "img_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        historyStore.add(
            HistoryItem(
                prompt = prompt,
                filePath = file.absolutePath,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    private fun refreshHistory() {
        historyAdapter.updateItems(historyStore.load())
        binding.tvHistoryLabel.visibility =
            if (historyAdapter.itemCount > 0) View.VISIBLE else View.GONE
    }

    private fun saveToGallery() {
        val bitmap = currentBitmap ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSaveAfterPermission = true
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE
            )
            return
        }
        doSaveToGallery(bitmap)
    }

    private fun doSaveToGallery(bitmap: Bitmap) {
        setLoading(true)
        scope.launch {
            try {
                withContext(Dispatchers.IO) { insertIntoMediaStore(bitmap) }
                Toast.makeText(
                    this@MainActivity, R.string.saved_gallery, Toast.LENGTH_SHORT
                ).show()
            } catch (_: Exception) {
                showError(getString(R.string.error_save))
            } finally {
                setLoading(false)
            }
        }
    }

    private fun insertIntoMediaStore(bitmap: Bitmap) {
        val fileName = "aiphoto_${System.currentTimeMillis()}.png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/AIPhotoMaker"
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ) ?: throw IllegalStateException("insert_failed")
        contentResolver.openOutputStream(uri)?.use { out ->
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw IllegalStateException("compress_failed")
            }
        } ?: throw IllegalStateException("stream_failed")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val done = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            contentResolver.update(uri, done, null, null)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STORAGE && pendingSaveAfterPermission) {
            pendingSaveAfterPermission = false
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                currentBitmap?.let { doSaveToGallery(it) }
            } else {
                showError(getString(R.string.error_save))
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnGenerate.isEnabled = !loading
    }

    private fun showError(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = View.VISIBLE
    }

    private fun hideError() {
        binding.tvError.visibility = View.GONE
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
