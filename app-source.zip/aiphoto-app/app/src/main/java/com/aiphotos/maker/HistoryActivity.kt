package com.aiphotos.maker

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.aiphotos.maker.databinding.ActivityViewBinding
import java.io.File

/** Full-screen viewer for one history item. */
class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityViewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val path = intent.getStringExtra(MainActivity.EXTRA_FILE_PATH)
        val prompt = intent.getStringExtra(MainActivity.EXTRA_PROMPT).orEmpty()

        if (path != null && File(path).exists()) {
            binding.tvPromptFull.text = prompt
            binding.ivFull.setImageBitmap(BitmapFactory.decodeFile(path))
        } else {
            binding.tvPromptFull.text = getString(R.string.error_missing_photo)
        }

        binding.btnBack.setOnClickListener { finish() }
    }
}
