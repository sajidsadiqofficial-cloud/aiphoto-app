# ProGuard rules (release builds keep everything; minify is disabled).
-keep class com.aiphotos.maker.** { *; }
