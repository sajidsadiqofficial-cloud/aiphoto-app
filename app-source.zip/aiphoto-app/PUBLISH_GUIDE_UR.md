# AI Photo Maker — Publish Guide (Phone se, bilkul FREE)

Tumhare paas computer nahi hai, sirf Android phone hai — koi baat nahi.
Tumhari app **GitHub** ke free cloud computer par banegi, aur tum usay
**bilkul free** me logon tak pahuncha sakte ho. Koi fee nahi.

## PART 1: APK banao (GitHub se, sirf phone par)

**Step 1 — GitHub account banao**
Phone ke browser me github.com kholo, "Sign up" dabao, free account bana lo.

**Step 2 — Nayi repository banao**
GitHub me "+" ya "New repository" dabao. Naam likho: `aiphoto-app`.
"Public" select karo, phir "Create repository" dabao.

**Step 3 — Project ZIP upload karo**
Tumhe jo ZIP file mili hai, us ka naam badal kar **`app-source.zip`**
rakh do. Phir repo me **"Add file" -> "Upload files"** dabao aur ye file
upload kar do. Bas EK file upload karni hai — bahut asaan.

**Step 4 — Build chalao**
Repo me **"Actions"** tab kholo. **"Build AAB & APK"** workflow select karo,
phir **"Run workflow"** dabao.

**Step 5 — 5-10 minute wait karo**
GitHub ka computer tumhari app bana raha hai. Jab green tick (✓) aa jaye,
neeche **"Artifacts"** me 3 cheezein milengi:
- `app-release.apk` — YEHI TUMHARI APP HAI. Isay download karo.
- `app-release.aab` — ye baad me stores ke kaam ayegi.
- `release-keystore-backup.zip` — (sirf pehli baar) YE SAB SE ZAROORI FILE HAI.

**Step 6 — Keystore backup sambhal ke rakho (BOHAT ZAROORI)**
`release-keystore-backup.zip` download karo aur apne **Google Drive** me save
karo. Ye file gum ho gayi to tum apni app ko kabhi UPDATE nahi kar sako ge
— ye Android ka rule hai, is me koi rasta nahi.

**Step 7 — GitHub Secrets me values dalo (sirf pehli baar)**
Backup zip ke andar `passwords.txt` aur `KEYSTORE_BASE64.txt` hain.
Repo me **Settings -> Secrets and variables -> Actions -> "New repository
secret"** me ye 4 secrets add karo:
1. `KEYSTORE_BASE64` = KEYSTORE_BASE64.txt ka poora text
2. `KEYSTORE_PASSWORD` = passwords.txt se
3. `KEY_ALIAS` = passwords.txt se
4. `KEY_PASSWORD` = passwords.txt se

Is ke baad jab bhi dobara build chalao ge, app usi key se sign hogi —
matlab updates kaam karenge.

## PART 2: APK logon tak pahunchao (FREE)

Tumhari `app-release.apk` tayyar hai. Ab isay share karo:

- **WhatsApp:** APK file kisi bhi chat ya group me bhejo — dost download kar
  ke install kar lenge.
- **Telegram:** Apna channel/group banao aur APK wahan upload karo.
- **Website:** Agar tumhari website hai to wahan download link laga do.

Install karte waqt phone poochega "Unknown sources se install allow karein?"
— ye normal hai, kyunke app Play Store se nahi aa rahi. User ko "Allow"
dabana hoga. Is me darne wali koi baat nahi.

**Har nayi version ke liye:** `versionCode` aur `versionName` barha kar dobara
build chalao (ye README me likha hai ke kahan change karna hai), nayi APK
share karo — purani app update ho jayegi.

## PART 3: Free app stores (optional, koi fee nahi)

Play Store ke $25 nahi dene? Ye 2 stores bilkul FREE hain:

**Amazon Appstore**
1. developer.amazon.com par free developer account banao.
2. "Add a New App" -> Android -> apni **AAB ya APK** upload karo.
3. Listing fill karo (PLAY_LISTING.md se title/description copy karo),
   screenshots lagao, submit karo.

**Huawei AppGallery**
1. developer.huawei.com par free account banao (ID verify karni parti hai).
2. AppGallery Connect me nayi app banao -> **AAB** upload karo.
3. Listing, screenshots, privacy policy URL do, submit karo.

Dono ka review 2-7 din me ho jata hai.

## PART 4: Jab $25 hon — Google Play Store (baad ke liye)

Jab tum afford kar sako, tab ye rasta hai:

1. **Play Console account:** play.google.com/console par $25 one-time fee de
   kar developer account banao (apne naam/email se).
2. **Nayi app banao:** Play Console me "Create app" dabao.
3. **AAB upload karo:** GitHub Actions se jo `app-release.aab` mili thi,
   wohi yahan upload hoti hai (Play Store par APK nahi, AAB chahiye hoti
   hai). "Testing -> Internal testing" track par upload karo.
4. **Listing fill karo:** PLAY_LISTING.md se title, short/long description
   copy karo. Feature graphic (1024x500), kam az kam 2 screenshots, aur app
   icon (512x512) lagao.
5. **Privacy policy URL:** PRIVACY_POLICY.md ko kisi web page par lagao
   (GitHub Pages ya Google Sites free hain) aur link yahan do — ye LAZMI hai.
6. **Content rating:** Questionnaire fill karo (sach sach jawab do).
7. **Review ke liye bhejo:** Sab complete ho jaye to "Send for review" dabao.
   Review me 2-7 din lagte hain. Approve hote hi app Play Store par LIVE!

## PART 5: Computer wala rasta (agar kabhi PC mil jaye)

Agar kabhi computer mil jaye to Android Studio install kar ke project khol
sakte ho (README.md me steps hain). Lekin zaroorat nahi — GitHub wala rasta
poori tarah kaam karta hai.

## Yaad rakhne wali 3 baatein

1. **Keystore backup (Google Drive) kabhi mat khona** — warna app update nahi
   ho sakegi.
2. **Har nayi version** me `versionCode` barhao (warna update install nahi
   hogi).
3. **Privacy policy** ka email (`your-email@example.com`) apne asli email se
   badal dena jab store par dalo.
