# Privacy Policy — AI Photo Maker

_Last updated: October 2026_

AI Photo Maker ("the app") is a creative tool that turns text descriptions
into AI-generated photos.

## Data we collect

**We do not collect, store, or share any personal data.** The app has no
accounts, no sign-up, no analytics, and no advertising SDKs.

## How image generation works

When you tap Generate, your text prompt is sent to the third-party service
**Pollinations.ai** (https://pollinations.ai), which returns the generated
image. That service processes the prompt to create the image; please refer to
their own privacy policy for how they handle requests. We do not attach your
name, email, or any identifier to these requests.

## On-device storage

- Generated photos are saved in the app's private storage on your device and
  in a local history list (last 20).
- If you tap "Save to Gallery", the photo is copied to your device's
  Pictures/AIPhotoMaker folder. Nothing is uploaded anywhere by the app.

## Children

The app is a general creative tool and is not directed at children under 13.

## Changes

If this policy changes, the updated version will be published at this same
URL.

## Contact

Questions about this policy: your-email@example.com
_(Replace with your real contact email before publishing.)_
