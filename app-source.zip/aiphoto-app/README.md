# AI Photo Maker

A native Android app (Kotlin) that generates AI photos from text using the free
[Pollinations.ai](https://pollinations.ai) image API (FLUX model). No API key,
no sign-up, no server needed.

Features:
- Text prompt → AI photo (5 styles, 3 sizes)
- Save to gallery (Pictures/AIPhotoMaker)
- History grid of recent generations (last 20), tap to view large
- 100% native — no WebView

## Project setup

- `applicationId`: `com.aiphotos.maker` (change it in `app/build.gradle.kts` if you want your own brand)
- `compileSdk` / `targetSdk`: 35, `minSdk`: 26, `versionCode`: 1, `versionName`: "1.0"
- AGP 8.6.1 + Kotlin 2.0.20 + Gradle 8.10.2

## Build path 1: Android Studio (needs a computer)

1. Open Android Studio → **File → Open** → select the `aiphoto-app` folder. Let it sync (it downloads everything automatically).
2. Debug APK: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. Find it at `app/build/outputs/apk/debug/app-debug.apk`.
3. Signed release AAB: **Build → Generate Signed App Bundle / APK** → choose **Android App Bundle** → create a new keystore (or reuse yours) → build `release`.

> ⚠️ **BIG WARNING — keystore backup:** the `.jks` keystore file + its passwords are the *identity* of your app. **Back them up (e.g. Google Drive) and never lose them.** If you lose the keystore, Google Play will NEVER let you update the app again — you would have to publish it as a brand-new app and lose all users/reviews.

## Build path 2: GitHub Actions (phone only, no computer)

1. Create a free account on github.com (phone browser is fine) and make a **new repository** (e.g. `aiphoto-app`, Public).
2. Rename the project ZIP to **`app-source.zip`** and upload it to the repo root (**Add file → Upload files**).
3. Go to the **Actions** tab → **Build AAB & APK** → **Run workflow**.
4. Wait ~5–10 minutes, then download from **Artifacts**:
   - `app-release.apk` — share directly (WhatsApp / Telegram / website), no fee
   - `app-release.aab` — for app-store uploads (Play / Amazon / Huawei)
5. **First run only:** also download `release-keystore-backup.zip`, save it to **Google Drive**, and add its 4 values as repo secrets (**Settings → Secrets and variables → Actions**): `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Future builds will then reuse the same signing key (required for updates).

See `PUBLISH_GUIDE_UR.md` (Roman Urdu) for the full step-by-step.

## How it works

`MainActivity` sends the prompt to `https://image.pollinations.ai/prompt/...`
on a background thread (coroutines + `HttpURLConnection`), decodes the PNG,
shows it, saves it to app-private storage, and records it in a JSON history
file. "Save to Gallery" uses MediaStore (`Pictures/AIPhotoMaker`).
